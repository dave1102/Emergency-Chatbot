# 🚨 Emergency Assistant PWA

A mobile-first, offline-capable emergency assistant powered by [Featherless AI](https://featherless.ai). Installs as a native-like app on any phone via "Add to Home Screen".

## Features

- 💬 **AI Chat** — powered by Qwen3, Mistral, or Gemma via Featherless AI
- 📴 **Offline mode** — 8 pre-loaded emergency guides (CPR, choking, fire, flood, etc.)
- 📍 **Location-aware** — auto-detects your country and shows local emergency numbers
- 🏥 **Hospital finder** — finds nearest hospitals, caches results for offline use
- 🆘 **SOS Share** — sends your GPS location to emergency contacts via SMS
- 📲 **PWA** — installs on your home screen, opens instantly like a native app

## Files

```
index.html      ← App shell & HTML structure
app.css         ← All styles
app.js          ← All logic (AI, location, contacts, hospitals, offline KB)
sw.js           ← Service worker (offline caching)
manifest.json   ← PWA manifest (icons, name, theme)
icon-192.svg    ← App icon (192×192)
icon-512.svg    ← App icon (512×512)
```

## Setup

### 1. Get a Featherless AI API key
1. Go to [featherless.ai](https://featherless.ai) and sign up
2. Navigate to **API Keys** and create a new key (starts with `fl-`)

### 2. Deploy to GitHub Pages
1. Push all files to a GitHub repo
2. Go to **Settings → Pages → Source** → select `main` branch → save
3. Your app will be live at `https://yourusername.github.io/your-repo/`

> **Why GitHub Pages?** The Service Worker requires HTTPS to work, which GitHub Pages provides for free.

### 3. Install on your phone
1. Open the GitHub Pages URL in **Chrome (Android)** or **Safari (iPhone)**
2. Tap the browser menu → **"Add to Home Screen"**
3. Paste your Featherless AI key on first launch — it's saved forever after that
4. Allow location access when prompted

## Offline behaviour

| Feature | Online | Offline |
|---|---|---|
| AI chat | ✅ Full AI responses | ✅ Pre-loaded guides |
| Location | ✅ GPS + country detection | ✅ GPS only (coordinates) |
| Emergency numbers | ✅ Auto by country | ✅ Cached from last session |
| Hospitals | ✅ Live search | ✅ Cached from last visit |
| SOS Share | ✅ | ✅ Uses cached GPS |
| Quick buttons | ✅ | ✅ Always instant |

## Emergency numbers supported

Nigeria, USA, UK, Ghana, South Africa, Kenya, India, Germany, France, Australia, Canada, Brazil — with `112` as universal fallback.

## ⚠️ Disclaimer

This app is a first-response guide only. **Always call your local emergency number first** in any life-threatening situation.
