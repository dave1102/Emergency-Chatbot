/* ═══════════════════════════════════════════════
   Emergency Assistant — app.js
   Featherless AI · PWA · Offline-first
   ═══════════════════════════════════════════════ */

// ── CONFIG ───────────────────────────────────────
const FL_URL  = 'https://api.featherless.ai/v1/chat/completions';
const MODELS  = {
  'Qwen/Qwen3-8B':                                  'Qwen3 8B',
  'Qwen/Qwen2.5-7B-Instruct':                       'Qwen2.5 7B',
  'mistralai/Mistral-Small-3.1-24B-Instruct-2503':  'Mistral 24B',
  'google/gemma-3-27b-it':                          'Gemma 3 27B',
};

// ── STATE ────────────────────────────────────────
let apiKey  = '';
let modelId = 'Qwen/Qwen3-8B';
let lat = null, lng = null, cc = 'XX', online = navigator.onLine;
let cachedH = null, cachedT = null, locLabel = 'unknown location';
let contacts = [], hist = [];
let deferredInstall = null;
let selModelId = modelId;

// Load persisted prefs
try { apiKey   = localStorage.getItem('fl_key')    || ''; }      catch(e){}
try { modelId  = localStorage.getItem('fl_model')  || modelId; } catch(e){}
try { contacts = JSON.parse(localStorage.getItem('em_contacts') || '[]'); } catch(e){}

// ── COUNTRY EMERGENCY NUMBERS ────────────────────
const NUMS = {
  NG: { n:'Nigeria',   e:'112', f:'01-7944079', a:'112'   },
  US: { n:'USA',       e:'911', f:'911',        a:'911'   },
  GB: { n:'UK',        e:'999', f:'999',        a:'999'   },
  GH: { n:'Ghana',     e:'112', f:'192',        a:'193'   },
  ZA: { n:'S.Africa',  e:'112', f:'10111',      a:'10177' },
  KE: { n:'Kenya',     e:'999', f:'999',        a:'999'   },
  IN: { n:'India',     e:'112', f:'101',        a:'102'   },
  DE: { n:'Germany',   e:'112', f:'112',        a:'112'   },
  FR: { n:'France',    e:'112', f:'18',         a:'15'    },
  AU: { n:'Australia', e:'000', f:'000',        a:'000'   },
  CA: { n:'Canada',    e:'911', f:'911',        a:'911'   },
  BR: { n:'Brazil',    e:'190', f:'193',        a:'192'   },
  XX: {                e:'112', f:'112',        a:'112'   },
};
const gn = () => NUMS[cc] || NUMS.XX;
const en = () => gn().e;

// ── OFFLINE KNOWLEDGE BASE ───────────────────────
const KB = [
  {
    kw: ['cpr','cardiac arrest','not breathing','no pulse','heart stopped','unconscious'],
    r: `CPR — act now:\n1. Call __NUM__ immediately\n2. Lay person flat on a firm surface\n3. Heel of hand on centre of chest, other hand on top\n4. Push hard & fast — 30 compressions at 100–120/min\n5. Tilt head back, lift chin, 2 rescue breaths (1 sec each)\n6. Repeat 30:2 until help arrives\n\nHands-only CPR (no breaths) is also effective.`
  },
  {
    kw: ['chok','heimlich',"can't breathe",'throat blocked','something stuck'],
    r: `Choking — act immediately:\n\nConscious adult/child:\n1. 5 firm back blows between shoulder blades\n2. 5 abdominal thrusts (Heimlich): fist above navel, thrust inward-upward\n3. Alternate until object clears\n\nIf unconscious → start CPR\nInfants under 1yr: 5 back blows + 5 chest thrusts ONLY`
  },
  {
    kw: ['bleed','blood','wound','cut','hemorrhage'],
    r: `Severe bleeding — stop it fast:\n1. Firm direct pressure with a clean cloth\n2. Do NOT remove cloth — add more if soaked through\n3. Hold for 10+ continuous minutes\n4. Raise limb above heart if possible\n5. Tourniquet if uncontrollable: 5–7 cm above wound, note the time\n6. Keep person warm and still — call __NUM__`
  },
  {
    kw: ['fire','smoke','burning','flames','house fire'],
    r: `House fire — get out NOW:\n1. Alert everyone — shout FIRE!\n2. Stay LOW — crawl below smoke\n3. Feel doors before opening — hot door = use another exit\n4. Close doors behind you (slows spread)\n5. Evacuate — no belongings\n6. Call fire dept from outside\n\nIf trapped: seal door gaps, signal from window\nClothes on fire: STOP, DROP, ROLL`
  },
  {
    kw: ['earthquake','quake','tremor','shaking ground'],
    r: `Earthquake — DROP, COVER, HOLD ON:\n\nDuring shaking:\n• Drop to hands and knees\n• Cover under sturdy table or against interior wall\n• Protect head/neck with arms\n• Stay away from windows & heavy objects\n\nAfter:\n• Check for injuries, expect aftershocks\n• Exit carefully — watch for debris\n• Smell gas? Leave immediately, call __NUM__`
  },
  {
    kw: ['flood','flash flood','rising water','water rising'],
    r: `Flood — move now:\n1. Go to higher ground immediately\n2. NEVER walk through moving water (15 cm can knock you over)\n3. NEVER drive through flooded roads\n4. Disconnect electrics if safe to do so\n\nIf trapped:\n• Move to the highest floor\n• Signal from roof or window\n• Call __NUM__ with your exact location`
  },
  {
    kw: ['burn','scald','hot water'],
    r: `Burns:\n1. Cool running water over burn for 20 minutes (not ice)\n2. Remove jewellery/clothing near burn (not if stuck)\n3. Cover loosely with cling film or clean cloth\n\nDo NOT use ice, butter, or toothpaste\n\nSeek emergency care if: larger than palm, on face/hands/feet, or deep/charred`
  },
  {
    kw: ['stroke','face drooping','arm weak','speech slurred'],
    r: `Stroke — use FAST:\nF — Face drooping (uneven smile?)\nA — Arm weakness (raise both — does one drift?)\nS — Speech slurred or strange?\nT — Time to call __NUM__ NOW\n\nWhile waiting:\n• Keep calm and still, lay on side if conscious\n• Do NOT give food or water\n• Note exact time symptoms started`
  },
];
const fo = t => {
  const l = t.toLowerCase();
  for (const d of KB) if (d.kw.some(k => l.includes(k))) return d.r.replace(/__NUM__/g, en());
  return null;
};

// ── SERVICE WORKER ───────────────────────────────
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => {});
  });
}

// ── PWA INSTALL PROMPT ───────────────────────────
window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  deferredInstall = e;
  setTimeout(() => {
    if (deferredInstall && document.getElementById('app').style.display !== 'none') {
      document.getElementById('install-bar').style.display = 'flex';
    }
  }, 3000);
});
window.addEventListener('appinstalled', () => {
  document.getElementById('install-bar').style.display = 'none';
  deferredInstall = null;
});
function installApp() {
  if (!deferredInstall) return;
  deferredInstall.prompt();
  deferredInstall.userChoice.then(() => {
    deferredInstall = null;
    document.getElementById('install-bar').style.display = 'none';
  });
}
function dismissInstall() {
  document.getElementById('install-bar').style.display = 'none';
}

// ── SETUP SCREEN ─────────────────────────────────
function selModel(el) {
  document.querySelectorAll('.model-opt').forEach(e => e.classList.remove('selected'));
  el.classList.add('selected');
  selModelId = el.dataset.model;
}
function toggleVis() {
  const i = document.getElementById('ki');
  i.type = i.type === 'password' ? 'text' : 'password';
}
function showSetup() {
  document.getElementById('setup').style.display = 'flex';
  document.getElementById('app').style.display   = 'none';
  document.getElementById('ki').value = apiKey;
  document.getElementById('serr').textContent    = '';
  const b = document.getElementById('sbtn');
  b.disabled    = false;
  b.textContent = 'Save & Launch App';
  document.querySelectorAll('.model-opt').forEach(el =>
    el.classList.toggle('selected', el.dataset.model === modelId)
  );
}
function hideSetup() {
  document.getElementById('setup').style.display = 'none';
  document.getElementById('app').style.display   = 'flex';
}
async function saveKey() {
  const val = document.getElementById('ki').value.trim();
  if (!val) { setErr('Please paste your Featherless AI API key.'); return; }
  const btn = document.getElementById('sbtn');
  btn.disabled = true; btn.textContent = 'Verifying…';
  const ok = await testKey(val, selModelId);
  if (ok) {
    apiKey = val; modelId = selModelId;
    try { localStorage.setItem('fl_key', val); localStorage.setItem('fl_model', modelId); } catch(e){}
    hideSetup(); init();
  } else {
    setErr('Verification failed — check your key or try a different model.');
    btn.disabled = false; btn.textContent = 'Save & Launch App';
  }
}
async function testKey(key, model) {
  try {
    const r = await fetch(FL_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + key },
      body: JSON.stringify({ model, max_tokens: 5, messages: [{ role: 'user', content: 'hi' }] })
    });
    return r.ok;
  } catch(e) { return false; }
}
function setErr(m) { document.getElementById('serr').textContent = m; }

// ── NETWORK STATUS ───────────────────────────────
const updStatus = () => {
  online = navigator.onLine;
  document.getElementById('dot').className  = 'dot' + (online ? '' : ' off');
  document.getElementById('stxt').textContent = online ? 'Online' : 'Offline';
};
window.addEventListener('online',  () => { updStatus(); if (lat && apiKey) loadHospitals(); });
window.addEventListener('offline', () => updStatus());

// ── SOS DIAL BUTTONS ─────────────────────────────
function callNum(type) {
  const n   = gn();
  const num = n[type];
  if (confirm('Call ' + num + (n.n ? ' (' + n.n + ')' : '') + '?')) {
    window.location.href = 'tel:' + num;
  }
}
const updDial = n => {
  document.getElementById('be').textContent = 'Call ' + n.e;
  document.getElementById('bf').textContent = 'Fire ' + n.f;
  document.getElementById('ba').textContent = 'Amb '  + n.a;
};

// ── LOCATION DETECTION ───────────────────────────
async function detectLocation() {
  if (!navigator.geolocation) {
    document.getElementById('ltxt').textContent = 'Location unavailable';
    return;
  }
  navigator.geolocation.getCurrentPosition(async pos => {
    lat = pos.coords.latitude;
    lng = pos.coords.longitude;
    locLabel = lat.toFixed(5) + ', ' + lng.toFixed(5);
    document.getElementById('ltxt').textContent = lat.toFixed(3) + '°, ' + lng.toFixed(3) + '° — detecting country…';
    upPrev();

    if (online && apiKey) {
      try {
        const reply = await flReq(
          'You are a geolocation assistant. Reply ONLY with compact JSON, no other text.',
          'GPS lat=' + lat.toFixed(4) + ' lng=' + lng.toFixed(4) + '. Reply ONLY: {"country":"Nigeria","code":"NG","city":"Lagos"}',
          80
        );
        const geo = JSON.parse(reply.replace(/```json|```/g, '').trim());
        cc       = geo.code || 'XX';
        locLabel = (geo.city || '') + (geo.country ? ', ' + geo.country : '') + ' (' + lat.toFixed(4) + ', ' + lng.toFixed(4) + ')';
        const n  = gn();
        document.getElementById('ltxt').textContent = (geo.city || '') + (geo.country ? ', ' + geo.country : '') + ' — Emergency: ' + n.e;
        updDial(n); upPrev(); loadHospitals();
        try { localStorage.setItem('em_location', JSON.stringify({ lat, lng, cc, locLabel })); } catch(e){}
      } catch(e) {
        document.getElementById('ltxt').textContent = lat.toFixed(3) + '°, ' + lng.toFixed(3) + '°';
        loadHospitals();
      }
    } else {
      // Restore cached country/city while offline
      try {
        const saved = JSON.parse(localStorage.getItem('em_location') || 'null');
        if (saved) { cc = saved.cc || 'XX'; locLabel = saved.locLabel || locLabel; updDial(gn()); }
      } catch(e){}
      document.getElementById('ltxt').textContent = lat.toFixed(3) + '°, ' + lng.toFixed(3) + '° (offline)';
    }
  }, () => {
    document.getElementById('ltxt').textContent = 'Location denied — enable in browser settings';
  }, { enableHighAccuracy: true, timeout: 14000 });
}

// ── FEATHERLESS AI ───────────────────────────────
async function flReq(system, user, maxTok = 900) {
  const r = await fetch(FL_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
    body: JSON.stringify({ model: modelId, max_tokens: maxTok, messages: [{ role: 'system', content: system }, { role: 'user', content: user }] })
  });
  if (!r.ok) { const e = await r.json().catch(() => ({})); throw new Error(e.error?.message || 'API ' + r.status); }
  return (await r.json()).choices?.[0]?.message?.content || '';
}

async function callAI(userMsg) {
  hist.push({ role: 'user', content: userMsg });
  const sys =
    'You are an emergency first-response assistant for the general public. ' +
    'ONLY help with medical emergencies (CPR, choking, bleeding, burns, stroke, allergic reactions), ' +
    'fire & safety, and natural disasters (earthquake, flood, tornado).\n' +
    'User location: ' + locLabel + '. Local emergency number: ' + en() + '.\n' +
    'Rules: numbered steps, mention ' + en() + ' for life-threatening cases, ' +
    'calm and direct, refuse non-emergency questions politely, plain text only.';
  const r = await fetch(FL_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + apiKey },
    body: JSON.stringify({ model: modelId, max_tokens: 800, messages: [{ role: 'system', content: sys }, ...hist] })
  });
  if (!r.ok) { const e = await r.json().catch(() => ({})); throw new Error(e.error?.message || 'API ' + r.status); }
  const reply = (await r.json()).choices?.[0]?.message?.content || '';
  hist.push({ role: 'assistant', content: reply });
  return reply;
}

// ── HOSPITAL FINDER ──────────────────────────────
const hav = (a, b, c, d) => {
  const R = 6371, dA = (c-a)*Math.PI/180, dB = (d-b)*Math.PI/180,
    e = Math.sin(dA/2)**2 + Math.cos(a*Math.PI/180)*Math.cos(c*Math.PI/180)*Math.sin(dB/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(e), Math.sqrt(1-e));
};

async function loadHospitals() {
  if (!lat) { document.getElementById('hl').innerHTML = '<div class="empty">Enable location access first.</div>'; return; }
  if (!online) { loadHospOff(); return; }
  document.getElementById('hl').innerHTML = '<div class="empty">Searching for nearby hospitals…</div>';
  document.getElementById('cnote').style.display = 'none';
  try {
    const reply = await flReq(
      'You are a hospital finder. Return ONLY a valid JSON array, no markdown.',
      'List 5 nearest real hospitals to GPS ' + lat.toFixed(4) + ', ' + lng.toFixed(4) +
      '. Return ONLY JSON: [{"name":"...","address":"...","phone":"...","lat":0.0,"lng":0.0,"type":"..."}]',
      900
    );
    const s = reply.indexOf('['), e = reply.lastIndexOf(']');
    const hs = JSON.parse(reply.slice(s, e+1));
    hs.forEach(h => { if (h.lat && h.lng) h.dist = hav(lat, lng, +h.lat, +h.lng); });
    hs.sort((a, b) => (a.dist||999) - (b.dist||999));
    cachedH = hs; cachedT = Date.now();
    try { localStorage.setItem('em_hospitals', JSON.stringify({ h: hs, t: cachedT })); } catch(e){}
    renderH(hs, false);
  } catch(e) {
    try { const s = JSON.parse(localStorage.getItem('em_hospitals') || 'null'); if (s) { cachedH = s.h; cachedT = s.t; } } catch(e){}
    cachedH ? loadHospOff() : document.getElementById('hl').innerHTML = '<div class="empty">Could not load hospitals. Check connection and tap Refresh.</div>';
  }
}

function loadHospOff() {
  if (!cachedH) {
    try { const s = JSON.parse(localStorage.getItem('em_hospitals') || 'null'); if (s) { cachedH = s.h; cachedT = s.t; } } catch(e){}
  }
  if (cachedH) { document.getElementById('cnote').style.display = 'block'; renderH(cachedH, true); }
  else document.getElementById('hl').innerHTML = '<div class="empty">No cached hospitals yet.<br>Go online once to load and cache nearby hospitals.</div>';
}

function renderH(hs, cached) {
  const list = document.getElementById('hl');
  if (!hs || !hs.length) { list.innerHTML = '<div class="empty">No hospitals found.</div>'; return; }
  list.innerHTML = '';
  hs.slice(0, 6).forEach(h => {
    const dist = h.dist ? (h.dist < 1 ? Math.round(h.dist*1000)+'m' : h.dist.toFixed(1)+'km') + ' away' : '';
    const hLat = +h.lat||0, hLng = +h.lng||0;
    const safe = (h.name||'').replace(/'/g, "\\'").replace(/"/g, '&quot;');
    const c = document.createElement('div'); c.className = 'hcard';
    c.innerHTML =
      '<div style="display:flex;justify-content:space-between;gap:8px"><h3>' + h.name + '</h3>' + (dist ? '<span class="hdist">' + dist + '</span>' : '') + '</div>' +
      '<div class="hmeta"><span>' + (h.type||'Hospital') + '</span>' + (h.address ? '<span>' + h.address + '</span>' : '') + '</div>' +
      '<div class="hacts">' +
        (h.phone ? '<button class="hb p" onclick="callH(\'' + h.phone + '\')">📞 ' + h.phone + '</button>' : '') +
        '<button class="hb" onclick="openM(' + hLat + ',' + hLng + ')">🗺 Directions</button>' +
        '<button class="hb" onclick="shareH(\'' + safe + '\',' + hLat + ',' + hLng + ')">📤 Share</button>' +
      '</div>';
    list.appendChild(c);
  });
  if (cached) {
    const n = document.createElement('div'); n.className = 'cnote';
    n.textContent = 'Cached ' + (cachedT ? Math.round((Date.now()-cachedT)/60000)+'min ago' : 'recently') + ' — connect to refresh';
    list.appendChild(n);
  }
}

function callH(p)  { if (confirm('Call ' + p + '?')) window.location.href = 'tel:' + p; }
function openM(a, b) { window.open('https://www.google.com/maps/dir/?api=1&destination=' + a + ',' + b, '_blank'); }
function shareH(name, a, b) {
  const msg = 'Nearest hospital: ' + name + '\nDirections: https://maps.google.com/?q=' + a + ',' + b;
  if (navigator.share) navigator.share({ title: 'Hospital', text: msg }).catch(() => {});
  else navigator.clipboard.writeText(msg).then(() => alert('Copied!')).catch(() => alert(msg));
}

// ── CONTACTS & SOS SHARE ─────────────────────────
const saveC = () => { try { localStorage.setItem('em_contacts', JSON.stringify(contacts)); } catch(e){} };

function renderC() {
  const list = document.getElementById('cl');
  if (!contacts.length) { list.innerHTML = '<div style="font-size:12px;color:#aaa;padding:2px 0">No contacts yet. Add one below.</div>'; return; }
  list.innerHTML = '';
  contacts.forEach((c, i) => {
    const row = document.createElement('div'); row.className = 'crow';
    const ini = (c.name||'?').split(' ').map(w => w[0]||'').join('').slice(0,2).toUpperCase();
    row.innerHTML =
      '<div class="cav">' + ini + '</div>' +
      '<div class="ci"><div class="cn">' + c.name + '</div><div class="cpn">' + c.phone + '</div></div>' +
      '<div class="cas"><button class="cb" onclick="smsC(' + i + ')">SMS</button><button class="cb del" onclick="rmC(' + i + ')">Remove</button></div>';
    list.appendChild(row);
  });
}

function addContact() {
  const name  = document.getElementById('cn').value.trim();
  const phone = document.getElementById('cph').value.trim();
  if (!name || !phone) { alert('Enter both name and phone number.'); return; }
  contacts.push({ name, phone }); saveC();
  document.getElementById('cn').value  = '';
  document.getElementById('cph').value = '';
  renderC();
}

function rmC(i) {
  if (!confirm('Remove ' + contacts[i].name + '?')) return;
  contacts.splice(i, 1); saveC(); renderC();
}

function buildMsg() {
  const name = document.getElementById('myname').value.trim() || 'Someone';
  const tmpl = document.getElementById('tmpl').value;
  const maps = lat ? 'https://maps.google.com/?q=' + lat + ',' + lng : '(location unavailable)';
  return tmpl.replace(/{name}/g, name).replace(/{location}/g, locLabel).replace(/{maps}/g, maps);
}

function upPrev() { document.getElementById('prev').textContent = buildMsg(); }
function smsC(i)  { window.open('sms:' + contacts[i].phone + '?body=' + encodeURIComponent(buildMsg()), '_blank'); }

function sendSOS() {
  if (!contacts.length) { alert('Add at least one emergency contact first.'); return; }
  const msg = buildMsg();
  if (navigator.share) navigator.share({ title: 'SOS Emergency', text: msg }).catch(() => fallSOS(msg));
  else fallSOS(msg);
}
function fallSOS(msg) {
  window.open('sms:' + contacts.map(c => c.phone).join(',') + '?body=' + encodeURIComponent(msg), '_blank');
}

// ── TAB SWITCHING ────────────────────────────────
function switchTab(tab) {
  ['chat','hospitals','sos'].forEach((t, i) =>
    document.querySelectorAll('.tab')[i].className = 'tab' + (t === tab ? ' active' : '')
  );
  document.getElementById('cp').style.display = tab === 'chat'      ? 'flex'  : 'none';
  document.getElementById('hp').style.display = tab === 'hospitals' ? 'flex'  : 'none';
  document.getElementById('sp').style.display = tab === 'sos'       ? 'flex'  : 'none';
  if (tab === 'hospitals' && !cachedH && lat && online) loadHospitals();
  if (tab === 'sos') { renderC(); upPrev(); }
}

// ── CHAT UI ──────────────────────────────────────
function addMsg(text, role) {
  const msgs = document.getElementById('msgs');
  const div  = document.createElement('div');
  div.className = 'msg ' + (role === 'user' ? 'usr' : 'bot');
  if (role === 'bot') {
    const s = document.createElement('span'); s.style.whiteSpace = 'pre-wrap'; s.textContent = text;
    const t = document.createElement('em');   t.className = 'stag';
    t.textContent = online
      ? '🤖 ' + (MODELS[modelId] || modelId) + ' via Featherless · ' + new Date().toLocaleTimeString()
      : '📴 Offline guide';
    div.appendChild(s); div.appendChild(t);
  } else {
    div.textContent = text;
  }
  msgs.appendChild(div);
  msgs.scrollTop = msgs.scrollHeight;
}

function showTyp() {
  const msgs = document.getElementById('msgs');
  const div  = document.createElement('div'); div.className = 'msg bot';
  div.innerHTML = '<div class="typ"><span></span><span></span><span></span></div>';
  msgs.appendChild(div); msgs.scrollTop = msgs.scrollHeight;
  return div;
}

async function handleSend() {
  const inp  = document.getElementById('ui');
  const text = inp.value.trim(); if (!text) return;
  inp.value  = ''; addMsg(text, 'user'); const t = showTyp();
  try {
    let reply;
    if (online && apiKey) {
      reply = await callAI(text);
    } else {
      await new Promise(r => setTimeout(r, 350));
      reply = fo(text) || 'I\'m offline. Call ' + en() + ' immediately, or tap a quick button above for a pre-loaded guide.';
    }
    t.remove(); addMsg(reply, 'bot');
  } catch(err) {
    t.remove();
    const off = fo(text);
    if (off) { online = false; updStatus(); addMsg(off, 'bot'); }
    else { addMsg('Error: ' + (err.message || 'Connection issue.') + '\n\nCall ' + en() + ' or use the quick buttons above.', 'bot'); }
  }
}

function qs(text) { switchTab('chat'); document.getElementById('ui').value = text; handleSend(); }

// ── INIT ─────────────────────────────────────────
function init() {
  updStatus();
  const wm = document.getElementById('wmsg');
  if (wm) wm.innerHTML =
    'Hi — I\'m your emergency assistant, powered by <strong>' + (MODELS[modelId] || modelId) + '</strong>.<br><br>' +
    'Tap a quick button above for <strong>instant offline help</strong>, or type your emergency below.<br><br>' +
    'Use <strong>SOS Share</strong> to send your GPS location to contacts instantly.' +
    '<em class="stag">Detecting location…</em>';
  try { const s = JSON.parse(localStorage.getItem('em_hospitals') || 'null'); if (s) { cachedH = s.h; cachedT = s.t; } } catch(e){}
  renderC(); upPrev(); detectLocation();
}

// ── BOOT ─────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  // Keyboard shortcut on API key input
  document.getElementById('ki').addEventListener('keydown', e => { if (e.key === 'Enter') saveKey(); });
  // Message template live preview
  document.getElementById('tmpl').addEventListener('input', upPrev);
  // Send on Enter
  document.getElementById('ui').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  });
  // Pre-select saved model
  selModelId = modelId;
  document.querySelectorAll('.model-opt').forEach(el =>
    el.classList.toggle('selected', el.dataset.model === modelId)
  );
  // Skip setup if key already saved
  if (apiKey) { hideSetup(); init(); }
});
